#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl> 

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_a0727d76(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_116cb345() {
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);
}


void f_3d4a3aba(inout vec4 vertex) {
    f_a0727d76(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_116cb345();
    }
    finalize();
}



void f_7b9180f1() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*texelFetch(Sampler2, UV2 / 16, 0);
}

void f_7d3ab90a() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_ef60c050(inout vec4 vertex) {
    f_a0727d76(vertex);
    f_7b9180f1();
    finalize();
}

void f_de84c271(inout vec4 vertex) {
    f_a0727d76(vertex);
    f_116cb345();
    f_7d3ab90a();
    finalize();
}

void f_92ff2144(inout vec4 vertex) {
    f_a0727d76(vertex);
    f_7d3ab90a();
    f_7b9180f1();
    finalize();
}

void f_15d4d6c7(inout vec4 vertex) {
    f_116cb345();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_a0727d76(vertex);
    finalize();
}

void f_836ba95f(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_7b9180f1();
    f_a0727d76(vertex);
    finalize();
}

void f_6574b810(inout vec4 vertex, float speed) {
    f_a0727d76(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*texelFetch(Sampler2, UV2 / 16, 0);
    finalize();
}



void f_873fb295(inout vec4 vertex) {
    f_a0727d76(vertex);
    f_116cb345();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {

    sphericalVertexDistance=fog_spherical_distance(Position);
    cylindricalVertexDistance=fog_cylindrical_distance(Position);
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);

    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_3d4a3aba(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_116cb345();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_a0727d76(vertex);
            f_116cb345();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_de84c271(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_de84c271(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_15d4d6c7(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_15d4d6c7(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_6574b810(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_873fb295(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_ef60c050(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_de84c271(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_92ff2144(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_15d4d6c7(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_836ba95f(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_6574b810(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_ef60c050(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_de84c271(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_92ff2144(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_15d4d6c7(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_836ba95f(vertex);
        return;
    }
    

    
    f_a0727d76(vertex);
    f_116cb345();
    finalize();
}