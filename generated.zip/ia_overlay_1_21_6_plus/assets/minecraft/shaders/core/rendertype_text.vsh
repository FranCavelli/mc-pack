#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl> 

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_d85cda25(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_fe58682b() {
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);
}


void f_147294ca(inout vec4 vertex) {
    f_d85cda25(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_fe58682b();
    }
    finalize();
}



void f_41b96f2e() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*texelFetch(Sampler2, UV2 / 16, 0);
}

void f_e0b525b6() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_0021cb2a(inout vec4 vertex) {
    f_d85cda25(vertex);
    f_41b96f2e();
    finalize();
}

void f_950d9419(inout vec4 vertex) {
    f_d85cda25(vertex);
    f_fe58682b();
    f_e0b525b6();
    finalize();
}

void f_9b6f60ff(inout vec4 vertex) {
    f_d85cda25(vertex);
    f_e0b525b6();
    f_41b96f2e();
    finalize();
}

void f_a32cec7e(inout vec4 vertex) {
    f_fe58682b();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_d85cda25(vertex);
    finalize();
}

void f_2598f971(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_41b96f2e();
    f_d85cda25(vertex);
    finalize();
}

void f_4e779a9b(inout vec4 vertex, float speed) {
    f_d85cda25(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*texelFetch(Sampler2, UV2 / 16, 0);
    finalize();
}



void f_664f5c65(inout vec4 vertex) {
    f_d85cda25(vertex);
    f_fe58682b();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {

    sphericalVertexDistance=fog_spherical_distance(Position);
    cylindricalVertexDistance=fog_cylindrical_distance(Position);
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);

    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_147294ca(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_fe58682b();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_d85cda25(vertex);
            f_fe58682b();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_950d9419(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_950d9419(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_a32cec7e(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_a32cec7e(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_4e779a9b(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_664f5c65(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_0021cb2a(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_950d9419(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_9b6f60ff(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_a32cec7e(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_2598f971(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_4e779a9b(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_0021cb2a(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_950d9419(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_9b6f60ff(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_a32cec7e(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_2598f971(vertex);
        return;
    }
    

    
    f_d85cda25(vertex);
    f_fe58682b();
    finalize();
}