#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl> 

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_701df756(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_b02f30c6() {
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);
}


void f_0b67c690(inout vec4 vertex) {
    f_701df756(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_b02f30c6();
    }
    finalize();
}



void f_7bcac3ff() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*texelFetch(Sampler2, UV2 / 16, 0);
}

void f_af729374() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_e29a4a2a(inout vec4 vertex) {
    f_701df756(vertex);
    f_7bcac3ff();
    finalize();
}

void f_544dbb36(inout vec4 vertex) {
    f_701df756(vertex);
    f_b02f30c6();
    f_af729374();
    finalize();
}

void f_33d9eaba(inout vec4 vertex) {
    f_701df756(vertex);
    f_af729374();
    f_7bcac3ff();
    finalize();
}

void f_2cc7c733(inout vec4 vertex) {
    f_b02f30c6();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_701df756(vertex);
    finalize();
}

void f_72b31914(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_7bcac3ff();
    f_701df756(vertex);
    finalize();
}

void f_3f2f53ff(inout vec4 vertex, float speed) {
    f_701df756(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*texelFetch(Sampler2, UV2 / 16, 0);
    finalize();
}



void f_dd7e5a19(inout vec4 vertex) {
    f_701df756(vertex);
    f_b02f30c6();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {

    sphericalVertexDistance=fog_spherical_distance(Position);
    cylindricalVertexDistance=fog_cylindrical_distance(Position);
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);

    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_0b67c690(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_b02f30c6();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_701df756(vertex);
            f_b02f30c6();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_544dbb36(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_544dbb36(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_2cc7c733(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_2cc7c733(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_3f2f53ff(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_dd7e5a19(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_e29a4a2a(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_544dbb36(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_33d9eaba(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_2cc7c733(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_72b31914(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_3f2f53ff(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_e29a4a2a(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_544dbb36(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_33d9eaba(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_2cc7c733(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_72b31914(vertex);
        return;
    }
    

    
    f_701df756(vertex);
    f_b02f30c6();
    finalize();
}