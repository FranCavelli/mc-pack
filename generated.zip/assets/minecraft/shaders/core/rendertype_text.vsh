#version 150

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;

uniform float GameTime;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_34b7e4c0(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_ea2d0d0d() {
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);
}


void f_340829eb(inout vec4 vertex) {
    f_34b7e4c0(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_ea2d0d0d();
    }
    finalize();
}



void f_b7d57760() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*texelFetch(Sampler2, UV2 / 16, 0);
}

void f_e8fcee4f() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_fd1cc421(inout vec4 vertex) {
    f_34b7e4c0(vertex);
    f_b7d57760();
    finalize();
}

void f_b867c6fb(inout vec4 vertex) {
    f_34b7e4c0(vertex);
    f_ea2d0d0d();
    f_e8fcee4f();
    finalize();
}

void f_c6c52801(inout vec4 vertex) {
    f_34b7e4c0(vertex);
    f_e8fcee4f();
    f_b7d57760();
    finalize();
}

void f_3e19d639(inout vec4 vertex) {
    f_ea2d0d0d();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_34b7e4c0(vertex);
    finalize();
}

void f_5bdc92b0(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_b7d57760();
    f_34b7e4c0(vertex);
    finalize();
}

void f_9b4d91bf(inout vec4 vertex, float speed) {
    f_34b7e4c0(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*texelFetch(Sampler2, UV2 / 16, 0);
    finalize();
}



void f_39c3639e(inout vec4 vertex) {
    f_34b7e4c0(vertex);
    f_ea2d0d0d();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {
    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_340829eb(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_ea2d0d0d();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_34b7e4c0(vertex);
            f_ea2d0d0d();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_b867c6fb(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_b867c6fb(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_3e19d639(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_3e19d639(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_9b4d91bf(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_39c3639e(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_fd1cc421(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_b867c6fb(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_c6c52801(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_3e19d639(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_5bdc92b0(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_9b4d91bf(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_fd1cc421(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_b867c6fb(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_c6c52801(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_3e19d639(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_5bdc92b0(vertex);
        return;
    }
    

    
    f_34b7e4c0(vertex);
    f_ea2d0d0d();
    finalize();
}