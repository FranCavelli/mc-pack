#version 150

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;

uniform float GameTime;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_0f1c4c39(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_1ae8fde4() {
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);
}


void f_abc1fae9(inout vec4 vertex) {
    f_0f1c4c39(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_1ae8fde4();
    }
    finalize();
}



void f_4215e6c3() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*texelFetch(Sampler2, UV2 / 16, 0);
}

void f_7e405c3d() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_fa8e97c9(inout vec4 vertex) {
    f_0f1c4c39(vertex);
    f_4215e6c3();
    finalize();
}

void f_01907d90(inout vec4 vertex) {
    f_0f1c4c39(vertex);
    f_1ae8fde4();
    f_7e405c3d();
    finalize();
}

void f_e32a68e6(inout vec4 vertex) {
    f_0f1c4c39(vertex);
    f_7e405c3d();
    f_4215e6c3();
    finalize();
}

void f_4c59b678(inout vec4 vertex) {
    f_1ae8fde4();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_0f1c4c39(vertex);
    finalize();
}

void f_1a94a778(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_4215e6c3();
    f_0f1c4c39(vertex);
    finalize();
}

void f_d90492c8(inout vec4 vertex, float speed) {
    f_0f1c4c39(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*texelFetch(Sampler2, UV2 / 16, 0);
    finalize();
}



void f_81464a4d(inout vec4 vertex) {
    f_0f1c4c39(vertex);
    f_1ae8fde4();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {
    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_abc1fae9(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_1ae8fde4();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_0f1c4c39(vertex);
            f_1ae8fde4();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_01907d90(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_01907d90(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_4c59b678(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_4c59b678(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_d90492c8(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_81464a4d(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_fa8e97c9(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_01907d90(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_e32a68e6(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_4c59b678(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_1a94a778(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_d90492c8(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_fa8e97c9(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_01907d90(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_e32a68e6(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_4c59b678(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_1a94a778(vertex);
        return;
    }
    

    
    f_0f1c4c39(vertex);
    f_1ae8fde4();
    finalize();
}