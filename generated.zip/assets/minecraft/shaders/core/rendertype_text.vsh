#version 150

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;

uniform float GameTime;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_a9ed62f3(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_c142641a() {
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);
}


void f_7aa1108d(inout vec4 vertex) {
    f_a9ed62f3(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_c142641a();
    }
    finalize();
}



void f_67647806() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*texelFetch(Sampler2, UV2 / 16, 0);
}

void f_7e551025() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_05b86a0f(inout vec4 vertex) {
    f_a9ed62f3(vertex);
    f_67647806();
    finalize();
}

void f_3171228f(inout vec4 vertex) {
    f_a9ed62f3(vertex);
    f_c142641a();
    f_7e551025();
    finalize();
}

void f_eaca5f44(inout vec4 vertex) {
    f_a9ed62f3(vertex);
    f_7e551025();
    f_67647806();
    finalize();
}

void f_15bada4e(inout vec4 vertex) {
    f_c142641a();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_a9ed62f3(vertex);
    finalize();
}

void f_57b86c18(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_67647806();
    f_a9ed62f3(vertex);
    finalize();
}

void f_3cfd4279(inout vec4 vertex, float speed) {
    f_a9ed62f3(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*texelFetch(Sampler2, UV2 / 16, 0);
    finalize();
}



void f_95057be2(inout vec4 vertex) {
    f_a9ed62f3(vertex);
    f_c142641a();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {
    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_7aa1108d(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_c142641a();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_a9ed62f3(vertex);
            f_c142641a();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_3171228f(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_3171228f(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_15bada4e(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_15bada4e(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_3cfd4279(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_95057be2(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_05b86a0f(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_3171228f(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_eaca5f44(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_15bada4e(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_57b86c18(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_3cfd4279(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_05b86a0f(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_3171228f(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_eaca5f44(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_15bada4e(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_57b86c18(vertex);
        return;
    }
    

    
    f_a9ed62f3(vertex);
    f_c142641a();
    finalize();
}