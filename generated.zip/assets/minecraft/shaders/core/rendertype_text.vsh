#version 150

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;

uniform float GameTime;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_9da73393(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_0fe01a39() {
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);
}


void f_0a5a11db(inout vec4 vertex) {
    f_9da73393(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_0fe01a39();
    }
    finalize();
}



void f_03bc4dca() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*texelFetch(Sampler2, UV2 / 16, 0);
}

void f_0d12aea7() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_345eee13(inout vec4 vertex) {
    f_9da73393(vertex);
    f_03bc4dca();
    finalize();
}

void f_86cfe00e(inout vec4 vertex) {
    f_9da73393(vertex);
    f_0fe01a39();
    f_0d12aea7();
    finalize();
}

void f_d03bc09a(inout vec4 vertex) {
    f_9da73393(vertex);
    f_0d12aea7();
    f_03bc4dca();
    finalize();
}

void f_71d57733(inout vec4 vertex) {
    f_0fe01a39();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_9da73393(vertex);
    finalize();
}

void f_5e25ec34(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_03bc4dca();
    f_9da73393(vertex);
    finalize();
}

void f_7b5ccc19(inout vec4 vertex, float speed) {
    f_9da73393(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*texelFetch(Sampler2, UV2 / 16, 0);
    finalize();
}



void f_19f7782e(inout vec4 vertex) {
    f_9da73393(vertex);
    f_0fe01a39();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {
    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_0a5a11db(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_0fe01a39();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_9da73393(vertex);
            f_0fe01a39();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_86cfe00e(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_86cfe00e(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_71d57733(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_71d57733(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_7b5ccc19(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_19f7782e(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_345eee13(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_86cfe00e(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_d03bc09a(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_71d57733(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_5e25ec34(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_7b5ccc19(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_345eee13(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_86cfe00e(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_d03bc09a(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_71d57733(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_5e25ec34(vertex);
        return;
    }
    

    
    f_9da73393(vertex);
    f_0fe01a39();
    finalize();
}