#version 150

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;

uniform float GameTime;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_12bb5893(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_f30a68ce() {
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);
}


void f_cd035387(inout vec4 vertex) {
    f_12bb5893(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_f30a68ce();
    }
    finalize();
}



void f_996b44c2() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*texelFetch(Sampler2, UV2 / 16, 0);
}

void f_c567c373() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_642f100c(inout vec4 vertex) {
    f_12bb5893(vertex);
    f_996b44c2();
    finalize();
}

void f_02ababf5(inout vec4 vertex) {
    f_12bb5893(vertex);
    f_f30a68ce();
    f_c567c373();
    finalize();
}

void f_92af91bb(inout vec4 vertex) {
    f_12bb5893(vertex);
    f_c567c373();
    f_996b44c2();
    finalize();
}

void f_dd46e4da(inout vec4 vertex) {
    f_f30a68ce();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_12bb5893(vertex);
    finalize();
}

void f_7a1d036e(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_996b44c2();
    f_12bb5893(vertex);
    finalize();
}

void f_5089d05c(inout vec4 vertex, float speed) {
    f_12bb5893(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*texelFetch(Sampler2, UV2 / 16, 0);
    finalize();
}



void f_acf9d287(inout vec4 vertex) {
    f_12bb5893(vertex);
    f_f30a68ce();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {
    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_cd035387(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_f30a68ce();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_12bb5893(vertex);
            f_f30a68ce();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_02ababf5(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_02ababf5(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_dd46e4da(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_dd46e4da(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_5089d05c(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_acf9d287(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_642f100c(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_02ababf5(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_92af91bb(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_dd46e4da(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_7a1d036e(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_5089d05c(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_642f100c(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_02ababf5(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_92af91bb(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_dd46e4da(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_7a1d036e(vertex);
        return;
    }
    

    
    f_12bb5893(vertex);
    f_f30a68ce();
    finalize();
}